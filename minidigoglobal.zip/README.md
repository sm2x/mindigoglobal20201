## Mindigoglobal

<p> This is a multilevel marketing platform by Pureweb </p>


## Contributors
Mr. Victor Asuquo (CEO vicSystems)


##Installation Instructions
<ul>
    <li><code> git clone</code> </li>
</ul>