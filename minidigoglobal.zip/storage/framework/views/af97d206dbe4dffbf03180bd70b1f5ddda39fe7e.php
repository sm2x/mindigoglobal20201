

<?php $__env->startSection('content'); ?>
    
    <div class="container-fluid maintanence-content">
        <div class="">
            <div class="maintanence-hero-img">
                <img alt="logo" src="<?php echo e(asset('storage/img/logo.svg')); ?>">
            </div>
            <h1 class="error-title">Under Maintenance</h1>
            <p class="error-text">Thank you for visiting us.</p>
            <p class="text">We are currently working on making some improvements <br/> to give you better user experience.</p>
            <p class="text">Please visit us again shortly.</p>
            <a href="index.html" class="btn btn-info mt-4">Home</a>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\cork-admin\ltr\vertical-dark-menu\resources\views/pages/pages/pages_maintenence.blade.php ENDPATH**/ ?>