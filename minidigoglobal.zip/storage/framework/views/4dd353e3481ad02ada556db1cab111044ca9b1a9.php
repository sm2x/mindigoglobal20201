<?php echo $__env->make('inc.function', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(setTitle($page_name)); ?></title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('storage/img/favicon.ico')); ?>"/>
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">

    <!-- Styles -->
    <?php echo $__env->make('inc.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
</head>
<body <?php echo e(($has_scrollspy) ? scrollspy($scrollspy_offset) : ''); ?> class=" <?php echo e(($page_name === 'alt_menu') ? 'alt-menu' : ''); ?> <?php echo e(($page_name === 'error404') ? 'error404 text-center' : ''); ?> <?php echo e(($page_name === 'error500') ? 'error500 text-center' : ''); ?> <?php echo e(($page_name === 'error503') ? 'error503 text-center' : ''); ?> <?php echo e(($page_name === 'maintenence') ? 'maintanence text-center' : ''); ?>">
    
    <!-- BEGIN LOADER -->
    <div id="load_screen"> <div class="loader"> <div class="loader-content">
        <div class="spinner-grow align-self-center"></div>
    </div></div></div>
    <!--  END LOADER -->

    <?php echo $__env->make('inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <!--  BEGIN MAIN CONTAINER  -->
    <div class="main-container" id="container">

        <div class="overlay"></div>
        <div class="search-overlay"></div>

        <?php echo $__env->make('inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!--  BEGIN CONTENT PART  -->
        <div id="content" class="main-content">

            <?php echo $__env->yieldContent('content'); ?>

            <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <!--  END CONTENT PART  -->

    </div>
    <!-- END MAIN CONTAINER -->

    <?php echo $__env->make('inc.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\cork-admin\ltr\vertical-dark-menu\resources\views/layouts/app.blade.php ENDPATH**/ ?>