<?php

namespace App\Http\Controllers;

use App\DirectReferral;
use Illuminate\Http\Request;

class DirectReferralController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\DirectReferral  $directReferral
     * @return \Illuminate\Http\Response
     */
    public function show(DirectReferral $directReferral)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\DirectReferral  $directReferral
     * @return \Illuminate\Http\Response
     */
    public function edit(DirectReferral $directReferral)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\DirectReferral  $directReferral
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DirectReferral $directReferral)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\DirectReferral  $directReferral
     * @return \Illuminate\Http\Response
     */
    public function destroy(DirectReferral $directReferral)
    {
        //
    }
}
