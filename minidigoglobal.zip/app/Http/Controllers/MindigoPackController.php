<?php

namespace App\Http\Controllers;

use App\MindigoPack;
use Illuminate\Http\Request;

class MindigoPackController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\MindigoPack  $mindigoPack
     * @return \Illuminate\Http\Response
     */
    public function show(MindigoPack $mindigoPack)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\MindigoPack  $mindigoPack
     * @return \Illuminate\Http\Response
     */
    public function edit(MindigoPack $mindigoPack)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\MindigoPack  $mindigoPack
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MindigoPack $mindigoPack)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\MindigoPack  $mindigoPack
     * @return \Illuminate\Http\Response
     */
    public function destroy(MindigoPack $mindigoPack)
    {
        //
    }
}
