<?php

namespace App\Http\Controllers;

use App\MatchingBonus;
use Illuminate\Http\Request;

class MatchingBonusController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\MatchingBonus  $matchingBonus
     * @return \Illuminate\Http\Response
     */
    public function show(MatchingBonus $matchingBonus)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\MatchingBonus  $matchingBonus
     * @return \Illuminate\Http\Response
     */
    public function edit(MatchingBonus $matchingBonus)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\MatchingBonus  $matchingBonus
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MatchingBonus $matchingBonus)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\MatchingBonus  $matchingBonus
     * @return \Illuminate\Http\Response
     */
    public function destroy(MatchingBonus $matchingBonus)
    {
        //
    }
}
