<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MindigoPack extends Model
{
    //
}
